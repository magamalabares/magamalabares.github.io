# -*- coding: utf-8 -*-
"""
Gerador de folhas de olhinhos em degradê – Sinint amigurumis
Gera um PDF A4 por tema (12 mm e 10 mm), com logo, fontes Fredoka/Quicksand e régua de 5 cm.
Uso:  python gerar_olhinhos.py      ->  PDFs na pasta "saida"
"""
import os
BASE=os.path.dirname(os.path.abspath(__file__))
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib.colors import HexColor, white

data=[
 ("FRIEREN",["#C2546A","#C2546A","#1F5F78","#2E8C93","#4FB39A","#9DD39A","#E4EBA0"],[0,2.5,9,30,55,78,100],"#2E8C93"),
 ("FERN",["#B04A9C","#3E1F78","#5E37B0","#7E55D2","#A07BE6","#C7A8F2"],[0,8,30,55,78,100],"#5E37B0"),
 ("HIMMEL",["#2A5C96","#4486C8","#70B0E6","#A2D0F2","#D6ECFC"],[0,25,55,80,100],"#4486C8"),
 ("MAOMAO",["#1C1A6B","#2A35A8","#3D57D6","#4F86E6","#7DBDF0","#A8DDF5"],[0,20,42,62,82,100],"#2A35A8"),
 ("JINSHI",["#2E1238","#5A2466","#843C90","#AB5EB2","#D088CE","#EDBEE6"],[0,18,40,62,82,100],"#843C90"),
 ("STARK",["#4E1216","#82222A","#AE3A3C","#CC5E58","#E2918A","#F2C0BA"],[0,18,40,62,82,100],"#AE3A3C"),
]
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import colorsys
FD=os.path.join(BASE,"fontes")+os.sep
pdfmetrics.registerFont(TTFont("Fredoka",FD+"Fredoka-SemiBold.ttf"))
pdfmetrics.registerFont(TTFont("Quicksand",FD+"Quicksand-Medium.ttf"))
pdfmetrics.registerFont(TTFont("QuicksandB",FD+"Quicksand-Bold.ttf"))
def viv(hx,sat=1.22):
    # boost saturation so colors survive glitter glue + cabochon; pull very light tones down a touch
    hx=hx.lstrip("#"); r,g,b=(int(hx[i:i+2],16)/255 for i in (0,2,4))
    h,l,s_=colorsys.rgb_to_hls(r,g,b); s_=min(1,s_*sat)
    if l>0.78: l-=0.035
    r,g,b=colorsys.hls_to_rgb(h,l,s_); return "#%02X%02X%02X"%(round(r*255),round(g*255),round(b*255))
def lighten(hx,t):
    hx=hx.lstrip("#"); r,g,b=(int(hx[i:i+2],16) for i in (0,2,4))
    return "#%02X%02X%02X"%tuple(round(v+(255-v)*t) for v in (r,g,b))
W,H=A4
c=canvas.Canvas(os.path.join(BASE,"saida","_rascunho.pdf"),pagesize=A4)
c.setTitle("Olhinhos em degradê v2 – 10mm e 12mm")
STROKE=0.25*mm
OUT=HexColor("#1b1b22")


import math
ST={
 "FRIEREN":dict(cres=("#EEF2A8",.55,.32)),
 "FERN":dict(glow=[("#D9B8FF",.55,.62,.0)],cres=("#C9A8F2",.6,.35),top=("#2A1450",.25,.22)),
 "HIMMEL":dict(cres=("#E6F2FC",.5,.30)),
 "STARK":dict(cres=("#F4C8BE",.45,.30),top=("#2A0608",.2,.2)),
 "MAOMAO":dict(glow=[("#2A1E8A",.4,.5,.04)],cres=("#8FD8F6",.7,.34)),
 "JINSHI":dict(glow=[("#F2A6E6",.5,.66,.02)],cres=("#EAB8E0",.4,.30)),
 "GYOKUYOU":dict(glow=[("#7CFFE6",.5,.6,.02)],cres=("#9CF6E0",.6,.36),top=("#002A28",.2,.2)),
 "LISHU":dict(cres=("#B8B6F6",.55,.33)),
 "LIHUA":dict(cres=("#F8C8D4",.5,.32),top=("#2A0612",.25,.22)),
 "AH-DUO":dict(cres=("#EAD4F2",.45,.32)),
 "LOULAN":dict(glow=[("#E8F070",.45,.6,.0)],cres=("#EAF0A0",.35,.30)),
 "XIAOLAN":dict(cres=("#F0D27A",.6,.34)),
 "ALAIRA":dict(cres=("#FAE6A0",.5,.32)),
 "AGOTT":dict(glow=[("#D2B6FF",.5,.6,.0)],cres=("#D8C4F6",.45,.32)),
 "TETIA":dict(glow=[("#FF8AAE",.5,.62,.0)],cres=("#FCCCDC",.5,.32)),
 "RICHEH":dict(cres=("#CCE6FC",.55,.33)),
 "COCO":dict(glow=[("#FFF06A",.6,.62,.0)],cres=("#F8F2AA",.5,.33)),
 "QIFREY":dict(glow=[("#B8F4FF",.55,.62,.02)],cres=("#A8EEFA",.55,.38)),
 "SHINOBU":dict(),
 "MITSURI":dict(glow=[("#D8FFA8",.5,.6,.0)],cres=("#E6F8C8",.45,.32)),
 "NEZUKO":dict(glow=[("#A8106A",.5,.66,.0)],cres=("#FCE0EE",.45,.32)),
 "ZENITSU":dict(glow=[("#FFE45A",.6,.66,.0)],cres=("#FCE6A8",.55,.34),top=("#3A1602",.2,.2)),
 "INOSUKE":dict(glow=[("#CFEAA0",.35,.6,.0)],cres=("#DEEAC0",.3,.30)),
 "SAILOR MOON":dict(cres=("#E2F2FE",.55,.34)),
 "SAILOR CHIBI MOON":dict(cres=("#FCD2D0",.55,.34),top=("#3A0608",.2,.2)),
 "SAILOR MERCURY":dict(cres=("#BEE4FE",.6,.36),top=("#061A5A",.2,.2)),
 "SAILOR MARS":dict(cres=("#F0E2FC",.5,.34)),
 "SAILOR JUPITER":dict(cres=("#D2F4DA",.5,.34),top=("#06240E",.2,.2)),
 "SAILOR VENUS":dict(cres=("#EAF0FE",.55,.34)),
 'LILLIA':dict(mist=("#FF8ED6",.55,200,340),cres=('#F8C8EC',.6,.36),top=('#4A1460',.2,.2)),
 'VIEGO':dict(glow=[("#A8FFE8",.6,.6,.0)],mist=("#00201A",.75,30,150),cres=('#C4FAEE',.55,.34),top=('#043632',.2,.2)),
 'JINX':dict(glow=[("#FF4FBF",.6,.66,.0)],cres=('#FCC6E6',.55,.34),top=('#4E0634',.2,.2)),
 'VI':dict(rim=("#1A2C36",.5,.11),cres=('#E4F4F6',.55,.34),top=('#2E4A58',.2,.2)),
 'CAITLYN':dict(rim=("#06243E",.6,.11),glow=[("#B8F0FF",.4,.55,.0)],cres=('#CCF0FA',.55,.34),top=('#0C3E66',.2,.2)),
 'AHRI':dict(glow=[("#FF7A00",.55,.62,.0)],cres=('#FDEFA4',.55,.34),top=('#5A3004',.2,.2)),
 'LUX':dict(glow=[("#E6FFFF",.6,.66,.0)],cres=('#CCF2F4',.55,.34),top=('#0E4A5E',.2,.2)),
 'GWEN':dict(gwen=True,cres=('#C8FAFC',.55,.34),top=('#04566A',.2,.2)),
 "KAI'SA":dict(mist=("#140A38",.7,20,160),glow=[("#CFC2FF",.45,.6,-.05)],cres=('#E2DCF8',.55,.34),top=('#2E2260',.2,.2)),
 'SORAKA':dict(glow=[("#FFD54A",.5,.66,.0)],cres=('#FCE4A2',.55,.34),top=('#6A3404',.2,.2)),
 'MISS FORTUNE':dict(cres=('#BEECEE',.55,.34),top=('#063E58',.2,.2)),
 'SERAPHINE':dict(cres=('#CCEAFE',.55,.34),top=('#0E3E86',.2,.2)),
 "TANJIRO":dict(glow=[("#F2505E",.55,.66,.0)],cres=("#F0B0BA",.35,.30)),
}
JIT=[0.0,0.35,-0.25,0.15,-0.4,0.3,-0.1,0.45,-0.3,0.2,-0.05,0.4,-0.35,0.1,0.25,-0.2,0.05,-0.45,0.3,-0.15,0.4,-0.25,0.15,-0.4,0.2,-0.1]

def soft_glow(cx,cy,R,col,a,N=60):
    # many faint discs, denser toward the edge -> smooth gaussian-like falloff, no visible rings
    # gaussian falloff: disc radii chosen so stacked coverage ~ exp(-rho^2/2s^2)
    c.setFillColor(HexColor(col)); c.setFillAlpha(a*18/N)
    sig=R/math.sqrt(2*math.log(N))
    for i in range(1,N+1):
        c.circle(cx,cy,sig*math.sqrt(2*math.log(N/i))+1e-3,stroke=0,fill=1)

MIST_SEEDS=[(0.95,.62),(1.25,.48),(1.62,.58),(2.05,.44),(2.45,.6),(2.9,.5),(0.6,.46),(2.75,.55)]
def soft_mist(cx,cy,r,col,a,arc,mirror):
    lo,hi=arc
    c.setFillColor(HexColor(col))
    for k,(u,sz) in enumerate(MIST_SEEDS):
        ang=lo+(hi-lo)*((u*0.37+k*0.131)%1)
        if mirror: ang=math.pi-ang
        px=cx+r*0.93*math.cos(ang); py=cy+r*0.93*math.sin(ang)
        for i in range(26):
            t=1-i/26; c.setFillAlpha(a*0.5)
            c.saveState(); c.translate(px,py); c.rotate(math.degrees(ang)+90)
            w=r*sz*0.8*t**0.6; h=r*sz*0.5*t**0.6
            c.ellipse(-w,-h,w,h,stroke=0,fill=1); c.restoreState()

import numpy as np
from PIL import Image as PImage, ImageDraw as PDraw, ImageFilter
from reportlab.lib.utils import ImageReader
FX_PX=640
_fx_cache={}
def _rgb(hx): hx=hx.lstrip("#"); return tuple(int(hx[i:i+2],16) for i in (0,2,4))
def fx_layer(key,st,side):
    k=(key,side)
    if k in _fx_cache: return _fx_cache[k]
    n=FX_PX; r=n/2
    yy,xx=np.mgrid[0:n,0:n].astype(np.float32)
    out=np.zeros((n,n,4),np.float32)
    def over(rgb,alpha):
        # straight (non-premultiplied) alpha "over" compositing
        a=np.clip(alpha,0,1)[...,None]; col=np.array(rgb,np.float32)/255
        ao=out[...,3:4]; na=a+ao*(1-a)
        out[...,:3]=np.where(na>0,(col*a+out[...,:3]*ao*(1-a))/np.maximum(na,1e-6),0)
        out[...,3:4]=na
    for (col,peak,f,oy) in st.get("glow",[]):
        gx=r; gy=r-oy*r; sig=f*r*0.5
        over(_rgb(viv(col,1.1)),peak*np.exp(-((xx-gx)**2+(yy-gy)**2)/(2*sig*sig)))
    if "arc" in st:
        # soft arched red crescent; fade interpolated in OKLCH (perceptual) so it stays clean, not gray or neon
        col,off,soft,base=st["arc"]; R2=1.75*r
        d2=np.sqrt((xx-r)**2+(yy-(off*r+R2))**2)
        t=np.clip((d2-R2)/(soft*r)+0.5,0,1); t=t*t*(3-2*t)
        def lin(u): u=np.asarray(u,np.float64); return np.where(u<=0.04045,u/12.92,((u+0.055)/1.055)**2.4)
        def delin(u): return np.where(u<=0.0031308,12.92*u,1.055*np.clip(u,0,None)**(1/2.4)-0.055)
        def to_lab(rgb):
            r_,g_,b_=lin(np.array(rgb)/255)
            l=0.4122214708*r_+0.5363325363*g_+0.0514459929*b_; m=0.2119034982*r_+0.6806995451*g_+0.1073969566*b_; s_=0.0883024619*r_+0.2817188376*g_+0.6299787005*b_
            l,m,s_=np.cbrt(l),np.cbrt(m),np.cbrt(s_)
            return (0.2104542553*l+0.7936177850*m-0.0040720468*s_, 1.9779984951*l-2.4285922050*m+0.4505937099*s_, 0.0259040371*l+0.7827717662*m-0.8086757660*s_)
        L1,A1,B1=to_lab(_rgb(viv(col))); L2,A2,B2=to_lab(_rgb(viv(base)))
        C1,h1=np.hypot(A1,B1),np.arctan2(B1,A1); C2,h2=np.hypot(A2,B2),np.arctan2(B2,A2)
        dh=(h2-h1+np.pi)%(2*np.pi)-np.pi
        L=L2+(L1-L2)*t-0.13*np.sin(np.pi*t); C=C2+(C1-C2)*t; hh=h1+dh*(1-t)   # dip into a darker tone mid-fade, like Fern's pink->deep violet
        A=C*np.cos(hh); B=C*np.sin(hh)
        l=(L+0.3963377774*A+0.2158037573*B)**3; m=(L-0.1055613458*A-0.0638541728*B)**3; s_=(L-0.0894841775*A-1.2914855480*B)**3
        R_=4.0767416621*l-3.3077115913*m+0.2309699292*s_; G_=-1.2684380046*l+2.6097574011*m-0.3413193965*s_; B_=-0.0041960863*l-0.7034186147*m+1.7076147010*s_
        out[...,0]=np.clip(delin(R_),0,1); out[...,1]=np.clip(delin(G_),0,1); out[...,2]=np.clip(delin(B_),0,1)
        out[...,3]=np.maximum(out[...,3],np.clip(t*1.4,0,1))
    if "octo_soft" in st:
        col,peak,fs=st["octo_soft"]
        m=PImage.new("L",(n,n),0); dr=PDraw.Draw(m)
        for fr in fs:
            pts=[(r+r*fr*math.cos(math.radians(22.5+45*j)),r-r*fr*math.sin(math.radians(22.5+45*j))) for j in range(8)]
            dr.line(pts+[pts[0]],fill=255,width=max(2,int(r*0.05)),joint="curve")
        m=m.filter(ImageFilter.GaussianBlur(r*0.035))
        over(_rgb(viv(col,1.1)),peak*np.asarray(m,np.float32)/255)
    if "rim" in st:
        col,peak,w=st["rim"]; rho=np.sqrt((xx-r)**2+(yy-r)**2)
        over(_rgb(viv(col,1.1)),peak*np.exp(-((r-rho)**2)/(2*(w*r)**2)))
    if "mist" in st:
        col,peak,lo,hi=st["mist"]
        m=PImage.new("L",(n,n),0); dr=PDraw.Draw(m)
        for kk,(u,sz) in enumerate(MIST_SEEDS):
            ang=math.radians(lo+(hi-lo)*((u*0.37+kk*0.131)%1))
            if side==1: ang=math.pi-ang
            px=r+r*0.95*math.cos(ang); py=r-r*0.95*math.sin(ang)
            w=r*sz*0.75; h=r*sz*0.5
            dr.ellipse([px-w,py-h,px+w,py+h],fill=255)
        m=m.filter(ImageFilter.GaussianBlur(r*0.13))
        over(_rgb(viv(col,1.1)),peak*np.asarray(m,np.float32)/255)
    img=PImage.fromarray((np.clip(out,0,1)*255).astype(np.uint8),"RGBA")
    _fx_cache[k]=ImageReader(img); return _fx_cache[k]

def stylize(cx,cy,d,st,side=0):
    r=d/2; k=d/(12*mm)
    if "top" in st:
        col,a,f=st["top"]; c.setFillColor(HexColor(col)); N=14
        c.setFillAlpha(a*0.7/N*1.6)
        for i in range(N):
            t=0.35+0.65*(i+1)/N; ff=f*1.25*t
            c.ellipse(cx-1.15*r,cy+r-2*ff*r,cx+1.15*r,cy+r+2*ff*r,stroke=0,fill=1)
    if "cres" in st:
        col,a,h=st["cres"]; c.setFillColor(HexColor(viv(col))); N=16
        c.setFillAlpha(a*0.75/N*1.7)
        for i in range(N):
            t=0.3+0.7*(i+1)/N; hh=h*1.2*t
            c.ellipse(cx-0.95*r*(0.6+0.4*t),cy-r-2*hh*r,cx+0.95*r*(0.6+0.4*t),cy-r+2*hh*r,stroke=0,fill=1)
    if "rings" in st:
        col,a,fs=st["rings"]; c.setStrokeColor(HexColor(col)); c.setStrokeAlpha(a); c.setLineWidth(0.12*mm*k)
        for f in fs: c.circle(cx,cy,r*f,stroke=1,fill=0)
    if "octo" in st:
        col,a,fs=st["octo"]; c.setStrokeColor(HexColor(col)); c.setStrokeAlpha(a); c.setLineWidth(0.16*mm*k)
        for f in fs:
            p=c.beginPath()
            for i in range(8):
                t=math.radians(22.5+45*i); x=cx+r*f*math.cos(t); y=cy+r*f*math.sin(t)
                (p.moveTo if i==0 else p.lineTo)(x,y)
            p.close(); c.drawPath(p,stroke=1,fill=0)
    if "streaks" in st:
        col,a,n,inner,reg=st["streaks"]; c.setStrokeColor(HexColor(col)); c.setStrokeAlpha(a); c.setLineWidth(0.07*mm*k)
        lo,hi={"top":(35,145),"bottom":(215,325),"all":(0,360)}[reg]
        step=(hi-lo)/(n if reg=="all" else n-1)
        for i in range(n):
            t=math.radians(lo+i*step+JIT[i%len(JIT)]*step*0.6)
            ri=r*(inner+0.08*abs(JIT[(i+5)%len(JIT)]))
            c.line(cx+ri*math.cos(t),cy+ri*math.sin(t),cx+r*math.cos(t),cy+r*math.sin(t))
    if "glow" in st or "mist" in st or "rim" in st or "arc" in st or "octo_soft" in st:
        c.setFillAlpha(1); c.setStrokeAlpha(1)   # graphics-state alpha also applies to images
        c.drawImage(fx_layer(st.get("_key"),st,side),cx-r,cy-r,2*r,2*r,mask="auto")
    if st.get("gwen"):
        # soft, smoky 4-point star like Gwen's splash: dark teal in one eye, magenta in the other
        col="#0B4652" if side==0 else "#FF1FA8"
        sc=cx; sy=cy+r*0.04; R=r*0.36
        base=0.040 if side==0 else 0.085
        rot=0
        if side==1:
            rot=45
            # darker blue disc behind the pink star, soft edge
            c.setFillColor(HexColor(viv("#0A4E78")))
            R=r*0.37
            for i in range(24):
                c.setFillAlpha(0.035); c.circle(sc,sy,r*(0.62-0.012*i),stroke=0,fill=1)
        c.setFillColor(HexColor(col)); N=20
        for i in range(N):
            k2=2.0-1.15*i/(N-1)           # wide & faint -> small & denser = smoky edge
            c.setFillAlpha(base)
            p=c.beginPath(); pts=[]
            for j in range(8):
                ang=math.radians(90+rot+45*j); rr=R*k2*(1 if j%2==0 else 0.44)
                pts.append((sc+rr*math.cos(ang),sy+rr*math.sin(ang)))
            p.moveTo(*pts[0])
            for q in pts[1:]: p.lineTo(*q)
            p.close(); c.drawPath(p,stroke=0,fill=1)
    if "speck" in st:
        col,x,y,rr=st["speck"]; c.setFillColor(HexColor(col)); c.setFillAlpha(.85)
        c.circle(cx+x*r,cy+y*r,rr*r,stroke=0,fill=1)

def _wing(L,ang,w,tilt=1):
    c.saveState(); c.rotate(ang)
    p=c.beginPath()
    p.moveTo(0,0)
    p.curveTo(L*0.22,w*0.85*tilt, L*0.78,w*1.05*tilt, L,w*0.18*tilt)
    p.curveTo(L*1.04,-w*0.12*tilt, L*0.72,-w*0.5*tilt, 0,0)
    p.close(); c.drawPath(p,stroke=0,fill=1)
    c.restoreState()

def butterfly(cx,cy,size):
    # side-view butterfly like the reference: tall upper wing, smaller back wing, two little lower wings
    u=size
    def shape():
        _wing(u*0.62, 62, u*0.20, 1)    # upper front wing, pointing up-right
        _wing(u*0.42, 128, u*0.15,-1)   # upper back wing, up-left
        _wing(u*0.36, -122, u*0.16, 1)  # lower left wing
        _wing(u*0.30, -58, u*0.14,-1)   # lower right wing
    c.saveState(); c.translate(cx,cy)
    # soft glow
    c.setFillColor(HexColor("#E2B6FA")); c.setFillAlpha(0.12)
    c.saveState(); c.scale(1.1,1.1); shape(); c.restoreState()
    # butterfly
    c.setFillColor(HexColor("#D69AF2")); c.setFillAlpha(0.62)
    shape()
    c.restoreState()

def eye(cx,cy,d,cols,pos,bf=False,st=None,side=0):
    r=d/2
    c.saveState()
    p=c.beginPath(); p.circle(cx,cy,r); c.clipPath(p,stroke=0,fill=0)
    c.linearGradient(cx,cy+r,cx,cy-r,[HexColor(viv(x)) for x in cols],[q/100 for q in pos],extend=True)
    if st: stylize(cx,cy,d,st,side)
    if bf: butterfly(cx+d*0.02,cy-d*0.22,d*0.34)
    c.restoreState()
    # outline drawn inside the edge so total diameter stays exactly d

def pill(x,cy,txt,col):
    c.setFillColor(HexColor(col))
    c.roundRect(x,cy-2.5*mm,12*mm,5*mm,2.5*mm,stroke=0,fill=1)
    c.setFillColor(white); c.setFont("QuicksandB",6.6)
    c.drawCentredString(x+6*mm,cy-0.8*mm,txt)

pair_w=2*12*mm+2*mm
x0=19*mm; avail=(W-6*mm)-x0
gap=(avail-6*pair_w)/5
centers=[]
for i in range(6):
    px=x0+i*(pair_w+gap)
    centers.append((px+6*mm, px+pair_w-6*mm))

data2=[
 ("GYOKUYOU",["#004E4C","#00786E","#00A894","#1ED4B6","#6CF0D4","#B8FCEC"],[0,18,40,62,82,100],"#00A894"),
 ("LISHU",["#1E1A5C","#34309A","#4C48C8","#6E6AE0","#9C9AEE","#C8C6F6"],[0,18,40,62,82,100],"#4C48C8"),
 ("LIHUA",["#4A0E24","#7E1C3C","#B03458","#D45A7A","#EA94A8","#F6C6D0"],[0,18,40,62,82,100],"#B03458"),
 ("AH-DUO",["#3A1E4E","#5E3678","#8452A0","#A878C0","#C9A2DA","#E6CFEE"],[0,18,40,62,82,100],"#8452A0"),
 ("LOULAN",["#2E2E08","#545410","#7E8018","#A2A62A","#C6CC5A","#E2E89A"],[0,18,40,62,82,100],"#7E8018"),
 ("XIAOLAN",["#3E1E08","#6E3A12","#9C5A1E","#C2802E","#D9A85A","#EACB8E"],[0,18,40,62,82,100],"#9C5A1E"),
]
data3=[
 ("ALAIRA",["#5A3A06","#8A5E10","#B8861E","#D8AE38","#ECD070","#F8E8AC"],[0,18,40,62,82,100],"#B8861E"),
 ("AGOTT",["#2A1A4E","#4A2E86","#6E48B8","#9470D6","#B89CEA","#DCCAF6"],[0,18,40,62,82,100],"#6E48B8"),
 ("TETIA",["#5E0E2E","#9A1E4A","#CC3A66","#E8608A","#F49AB6","#FCCADA"],[0,18,40,62,82,100],"#CC3A66"),
 ("RICHEH",["#1A2E78","#2A4CB0","#4070D6","#6698EC","#9CC2F6","#CCE2FC"],[0,18,40,62,82,100],"#4070D6"),
 ("COCO",["#4C3E06","#7E6A0E","#AE9A18","#D0C230","#E6DE6A","#F4F2AA"],[0,18,40,62,82,100],"#AE9A18"),
 ("QIFREY",["#0A3A66","#0E5E96","#1688C0","#34B0DE","#7AD6F0","#C0EEFA"],[0,18,40,62,82,100],"#1688C0"),
]
data4=[
 ("SHINOBU",["#E8DCF4","#E2C8F0","#B84ACC","#7E2E9C","#58207C","#3A1260"],[0,14,30,46,72,100],"#7A44B8"),
 ("MITSURI",["#2E6A2A","#4E9440","#76B85C","#9CD47A","#C2E8A0","#E2F6C8"],[0,18,40,62,82,100],"#5E9E46"),
 ("NEZUKO",["#8A1E5E","#B83A80","#D85E9E","#EC8CBC","#F6B8D6","#FCDCEC"],[0,18,40,62,82,100],"#C8488C"),
 ("ZENITSU",["#6A2E06","#A04E0A","#C87414","#E09A2A","#F0C060","#F8E0A0"],[0,18,40,62,82,100],"#D88418"),
 ("INOSUKE",["#2E4A1E","#4E6E30","#729448","#96B464","#BCD28E","#DEEAC0"],[0,18,40,62,82,100],"#5E7E3A"),
 ("TANJIRO",["#3A0A10","#6A1420","#962434","#BC4050","#D87484","#ECAAB4"],[0,18,40,62,82,100],"#962434"),
]
data5=[
 ("SAILOR MOON",["#1E3E8C","#2E5EBE","#4A86DE","#74AEEE","#A8D2F8","#D6ECFC"],[0,18,40,62,82,100],"#4A86DE"),
 ("SAILOR CHIBI MOON",["#6A0E14","#A41E24","#D23A38","#E8665E","#F49E98","#FCCCCA"],[0,18,40,62,82,100],"#D23A38"),
 ("SAILOR MERCURY",["#0A2A8A","#1446C8","#2A6CEA","#4E96F6","#86C2FC","#C2E2FE"],[0,18,40,62,82,100],"#1446C8"),
 ("SAILOR MARS",["#3A1E6A","#5E3A9E","#8A62C8","#AE8CE0","#CEB4F0","#EADAFA"],[0,18,40,62,82,100],"#6E4AB0"),
 ("SAILOR JUPITER",["#123E22","#1E6A3A","#2E9454","#52B874","#8CD6A0","#C6EED0"],[0,18,40,62,82,100],"#2E9454"),
 ("SAILOR VENUS",["#24387E","#3A56B0","#5A7ED4","#86A6E8","#B6CCF4","#E0EAFC"],[0,18,40,62,82,100],"#5A7ED4"),
]
data6=[
 ('LILLIA',['#3A1A70', '#5634A8', '#7258D4', '#A084EC', '#D0A8F0', '#F4D0F0'],[0, 18, 40, 62, 82, 100],'#7E5AD0'),
 ('VIEGO',['#043632', '#0A6058', '#129482', '#2CC8AA', '#78ECD2', '#C4FAEE'],[0, 18, 40, 62, 82, 100],'#129482'),
 ('JINX',['#4E0634', '#82105A', '#C71585', '#E048A6', '#F28ACA', '#FCC6E6'],[0, 18, 40, 62, 82, 100],'#C71585'),
 ('VI',['#2E4A58', '#4E7482', '#7AA2AE', '#A4CCD4', '#C6E4EA', '#E4F4F6'],[0, 18, 40, 62, 82, 100],'#6E98A4'),
 ('CAITLYN',['#0C3E66', '#14649A', '#2A92C6', '#52BAE2', '#90DAF2', '#CCF0FA'],[0, 18, 40, 62, 82, 100],'#2A92C6'),
 ('AHRI',['#5A3004', '#94520A', '#CC8410', '#EDB424', '#F8D856', '#FDEFA4'],[0, 18, 40, 62, 82, 100],'#CC8410'),
]
data7=[
 ('LUX',['#0E4A5E', '#16728A', '#2A9EB4', '#56C2D2', '#94DEE6', '#CCF2F4'],[0, 18, 40, 62, 82, 100],'#2A9EB4'),
 ('GWEN',['#04566A', '#0A8098', '#14AEC4', '#36D2E0', '#80ECF2', '#C8FAFC'],[0, 18, 40, 62, 82, 100],'#14AEC4'),
 ("KAI'SA",['#2E2260', '#4A3A8E', '#6E5EB8', '#9488D6', '#BCB2EC', '#E2DCF8'],[0, 18, 40, 62, 82, 100],'#6E5EB8'),
 ('SORAKA',['#6A3404', '#A2560A', '#D28016', '#ECA830', '#F6CA64', '#FCE4A2'],[0, 18, 40, 62, 82, 100],'#D28016'),
 ('MISS FORTUNE',['#063E58', '#0C6482', '#168CA6', '#32AEC0', '#76CED8', '#BEECEE'],[0, 18, 40, 62, 82, 100],'#168CA6'),
 ('SERAPHINE',['#0E3E86', '#165EBA', '#2A86E0', '#56AEF2', '#92D0FA', '#CCEAFE'],[0, 18, 40, 62, 82, 100],'#2A86E0'),
]
def sparkle(x,y,s):
    p=c.beginPath(); p.moveTo(x,y+s)
    for (dx,dy) in [(0.22,0.22),(1,0),(0.22,-0.22),(0,-1),(-0.22,-0.22),(-1,0),(-0.22,0.22),(0,1)]:
        p.lineTo(x+dx*s,y+dy*s)
    p.close(); c.drawPath(p,stroke=0,fill=1)

def header(name,hc,y):
    x0,x1=6*mm,W-6*mm; hgt=8*mm; yb=y-hgt
    c.saveState()
    p=c.beginPath(); p.roundRect(x0,yb,x1-x0,hgt,4*mm); c.clipPath(p,stroke=0,fill=0)
    c.linearGradient(x0,yb,x1,yb,[HexColor(lighten(hc,.16)),HexColor(hc),HexColor(hc),HexColor(lighten(hc,.16))],[0,.3,.7,1],extend=True)
    c.restoreState()
    # crochet-like stitched line, very subtle
    c.saveState(); c.setStrokeColor(white); c.setStrokeAlpha(.42); c.setLineWidth(0.45)
    c.setDash(2.2,1.8); c.roundRect(x0+1.1*mm,yb+1.1*mm,x1-x0-2.2*mm,hgt-2.2*mm,2.9*mm,stroke=1,fill=0)
    c.restoreState()
    # name
    t=c.beginText(); t.setFont("Fredoka",13.5); t.setCharSpace(0.8)
    tw=pdfmetrics.stringWidth(name,"Fredoka",13.5)+0.8*(len(name)-1)
    t.setTextOrigin(W/2-tw/2,yb+hgt/2-1.65*mm); c.setFillColor(white); t.textLine(name); c.drawText(t)
    # tiny sparkles flanking the name
    c.saveState(); c.setFillColor(white); c.setFillAlpha(.85)
    for sx in (-1,1):
        sparkle(W/2+sx*(tw/2+4.2*mm),yb+hgt/2,1.05*mm)
        c.setFillAlpha(.5); sparkle(W/2+sx*(tw/2+7*mm),yb+hgt/2+0.3*mm,0.6*mm); c.setFillAlpha(.85)
    c.restoreState()

# v2: keep the soft effects only for these characters
KEEP_FX={"NEZUKO","VIEGO","LILLIA","SHINOBU","MITSURI","ZENITSU","INOSUKE","TANJIRO"}
# Kimetsu: reference details, softened
ST["SHINOBU"].update(glow=[("#D25AD2",.28,.75,.42)])                  # magenta haze in the upper band
ST["MITSURI"].update(glow=[("#DCFFB0",.38,.62,.0)])                   # lighter center
ST["ZENITSU"].update(glow=[("#FFE070",.42,.64,.0)])                   # golden center
ST["INOSUKE"].update(glow=[("#D6F0A8",.28,.55,.0)],octo_soft=("#2E4A1E",.22,[.48,.72]))  # faint octagon rings
ST["TANJIRO"].update(glow=[("#EE5060",.4,.62,.0)],rim=("#2A0408",.28,.12))           # brighter center, dark edge
for _n,_st in ST.items():
    if _n not in KEEP_FX:
        for _k in ("glow","mist","rim","octo_soft"): _st.pop(_k,None)

TOP=14*mm
def page(data):
  y=H-TOP
  for row in data:
      name,cols,pos,hc=row[:4]; bf=len(row)>4
      header(name,hc,y)
      y-=8*mm+3.5*mm
      cy=y-6*mm
      pill(4*mm,cy,"12MM",hc)
      for a,b in centers:
          ST[name]["_key"]=name; eye(a,cy,12*mm,cols,pos,bf,ST[name],0); eye(b,cy,12*mm,cols,pos,bf,ST[name],1)
      y-=12*mm+3.5*mm
      cy=y-5*mm
      pill(4*mm,cy,"10MM",hc)
      for a,b in centers:
          eye(a,cy,10*mm,cols,pos,bf,ST[name],0); eye(b,cy,10*mm,cols,pos,bf,ST[name],1)
      y-=10*mm+5*mm

  ruler()
EXTRA_BROWN="#8A5A3C"
def extras(data,y):
    # compact block: 4 pairs of 9 mm + 4 pairs of 8 mm per character, one line each
    header("TAMANHOS EXTRAS",EXTRA_BROWN,y); y-=8*mm
    x0=29*mm; g9=x0; g8=x0+87.5*mm+6*mm
    c.setFillColor(HexColor(EXTRA_BROWN)); c.setFont("QuicksandB",7)
    c.drawCentredString(g9+87.5*mm/2,y-3.2*mm,"9 MM"); c.drawCentredString(g8+79.5*mm/2,y-3.2*mm,"8 MM")
    y-=5*mm
    for row in data:
        name,cols,pos,hc=row[:4]; bf=len(row)>4
        cy=y-4.5*mm; ST[name]["_key"]=name
        c.setFillColor(HexColor(hc)); c.roundRect(4*mm,cy-2.5*mm,22*mm,5*mm,2.5*mm,stroke=0,fill=1)
        c.setFillColor(white); c.setFont("QuicksandB",6.4); c.drawCentredString(15*mm,cy-0.8*mm,name)
        for i in range(4):
            a=g9+i*22.5*mm+4.5*mm; eye(a,cy,9*mm,cols,pos,bf,ST[name],0); eye(a+11*mm,cy,9*mm,cols,pos,bf,ST[name],1)
            a=g8+i*20.5*mm+4*mm;   eye(a,cy,8*mm,cols,pos,bf,ST[name],0); eye(a+10*mm,cy,8*mm,cols,pos,bf,ST[name],1)
        y-=12*mm

def page_double(data):
  # characters with twice as many eyes: two rows of 12 mm and two rows of 10 mm
  y=H-TOP
  for row in data:
      name,cols,pos,hc=row[:4]; bf=len(row)>4
      header(name,hc,y); y-=8*mm+3.5*mm
      ST[name]["_key"]=name
      for k,sz in enumerate((12,12,10,10)):
          cy=y-sz/2*mm
          pill(4*mm,cy,f"{sz}MM",hc)
          for a,b in centers:
              eye(a,cy,sz*mm,cols,pos,bf,ST[name],0); eye(b,cy,sz*mm,cols,pos,bf,ST[name],1)
          y-=sz*mm+(3.5*mm if k<3 else 5*mm)
  ruler()

def page_ext(data):
  # incomplete sheet: each character also gets 9 mm and 8 mm rows
  y=H-TOP
  for row in data:
      name,cols,pos,hc=row[:4]; bf=len(row)>4
      header(name,hc,y); y-=8*mm+3*mm
      ST[name]["_key"]=name
      for k,sz in enumerate((12,10,9,8)):
          cy=y-sz/2*mm
          pill(4*mm,cy,f"{sz}MM",hc)
          for a,b in centers:
              eye(a,cy,sz*mm,cols,pos,bf,ST[name],0); eye(b,cy,sz*mm,cols,pos,bf,ST[name],1)
          y-=sz*mm+(3*mm if k<3 else 4.5*mm)
  ruler()
def ruler():
 ry=10*mm; rx=10*mm
 c.setStrokeColor(HexColor("#333333")); c.setLineWidth(0.3)
 c.line(rx,ry,rx+50*mm,ry)
 for i in range(51):
     h=(3 if i%10==0 else 1.8 if i%5==0 else 1)*mm
     c.line(rx+i*mm,ry,rx+i*mm,ry+h)
 c.setFillColor(HexColor("#333333")); c.setFont("Quicksand",6)
 for i in range(0,51,10): c.drawCentredString(rx+i*mm,ry-2.6*mm,str(i//10) if i else "0")
 c.drawString(rx+52*mm,ry-0.8*mm,"cm")
 c.setFont("Quicksand",7.2)
 c.drawString(rx+62*mm,ry+0.8*mm,"Imprima em TAMANHO REAL (100%), sem 'ajustar à página'.")
 c.drawString(rx+62*mm,ry-2.4*mm,"Confira com uma régua: a linha ao lado deve medir exatamente 5 cm.")


# ---------- one PDF per theme, alphabetical, with logo ----------
from reportlab.lib.utils import ImageReader as _IR
from reportlab.pdfgen import canvas as _cv
LOGO=_IR(os.path.join(BASE,"logo.png")); LW,LH=LOGO.getSize()
ALL={row[0]:row for dd in (data,data2,data3,data4,data5,data6,data7) for row in dd}
THEMES=[
 ("Frieren","olhinhos_Frieren.pdf",["FRIEREN","FERN","HIMMEL","STARK"]),
 ("Diários de uma Apotecária","olhinhos_Diarios_de_uma_Apotecaria.pdf",["MAOMAO","JINSHI","GYOKUYOU","LISHU","LIHUA","AH-DUO","LOULAN","XIAOLAN"]),
 ("Witch Hat Atelier","olhinhos_Witch_Hat_Atelier.pdf",["ALAIRA","AGOTT","TETIA","RICHEH","COCO","QIFREY"]),
 ("Kimetsu no Yaiba","olhinhos_Kimetsu_no_Yaiba.pdf",["SHINOBU","MITSURI","NEZUKO","ZENITSU","INOSUKE","TANJIRO"]),
 ("Sailor Moon","olhinhos_Sailor_Moon.pdf",["SAILOR MOON","SAILOR CHIBI MOON","SAILOR MERCURY","SAILOR MARS","SAILOR JUPITER","SAILOR VENUS"]),
 ("League of Legends","olhinhos_League_of_Legends.pdf",["LILLIA","VIEGO","JINX","VI","CAITLYN","AHRI","LUX","GWEN","KAI'SA","SORAKA","MISS FORTUNE","SERAPHINE"]),
]
BROWN=HexColor("#4A2C1E")
def topbar(theme,pi,pn):
    lh=9*mm; lw=lh*LW/LH
    c.drawImage(LOGO,6*mm,H-5*mm-lh,lw,lh,mask="auto")
    c.setFillColor(BROWN); c.setFont("Fredoka",13)
    c.drawRightString(W-6*mm,H-11.6*mm,theme)
    if pn>1:
        c.setFont("Quicksand",7.5); c.drawRightString(W-6*mm,H-15.2*mm,f"folha {pi} de {pn}")
TOP=20*mm
import unicodedata
def key(n): return unicodedata.normalize("NFKD",n).replace("'","").replace("-","").lower()
for theme,fn,names in THEMES:
    rows=[ALL[n] for n in sorted(names,key=key)]
    chunks=[rows[i:i+6] for i in range(0,len(rows),6)]
    double=set()
    if fn.startswith("olhinhos_Diarios"):
        # Jinshi goes to Maomao's sheet (swapped with Xiaolan); those two get twice the eyes
        p1=[ALL[n] for n in sorted(["AH-DUO","GYOKUYOU","LIHUA","LISHU","LOULAN","XIAOLAN"],key=key)]
        chunks=[p1,[ALL["JINSHI"],ALL["MAOMAO"]]]; double={2}
    c=_cv.Canvas(os.path.join(BASE,"saida",fn),pagesize=A4); c.setTitle(f"Olhinhos {theme} – Sinint amigurumis")
    for i,ch in enumerate(chunks,1):
        topbar(theme,i,len(chunks)); (page_double(ch) if i in double else page(ch))
        c.showPage()
    c.save(); print(fn,[r[0] for r in rows])
