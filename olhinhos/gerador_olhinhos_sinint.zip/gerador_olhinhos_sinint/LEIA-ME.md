# Gerador de olhinhos – Sinint amigurumis

Gera as folhas A4 de olhinhos em degradê (12 mm e 10 mm), uma por tema, com a sua logo,
as fontes Fredoka/Quicksand e a régua de 5 cm no rodapé.

## O que tem na pasta

| Arquivo | Para que serve |
|---|---|
| `gerar_olhinhos.py` | O script. Tudo (cores, personagens, temas) está dentro dele. |
| `logo.png` | A logo usada no topo das folhas. Troque por uma versão maior com o mesmo nome se quiser mais nitidez. |
| `fontes/` | Fredoka e Quicksand (licença SIL OFL, que permite uso comercial). |
| `saida/` | Onde os PDFs aparecem. |

## Como rodar

1. Instale o Python 3.10 ou mais novo (python.org). No Windows, marque "Add Python to PATH" na instalação.
2. Abra o terminal nesta pasta e instale as bibliotecas (só na primeira vez):
   ```
   pip install reportlab pillow numpy
   ```
3. Rode:
   ```
   python gerar_olhinhos.py
   ```
4. Os PDFs ficam na pasta `saida`.

## Como adicionar ou ajustar um personagem

Tudo é feito editando `gerar_olhinhos.py` num editor de texto (VS Code, Bloco de Notas etc.).

**1. Cores do degradê.** Nas listas `data`, `data2` … `data7` (perto das linhas 14 e 295–340), cada personagem é uma linha:

```python
("NOME", ["#cor_topo", "#cor2", "#cor3", "#cor4", "#cor5", "#cor_base"], [0, 18, 40, 62, 82, 100], "#cor_da_faixa"),
```

- As cores vão de cima para baixo da íris.
- Os números dizem onde cada cor fica, em % da altura (0 = topo, 100 = base). Precisa ter um número para cada cor.
- Para uma faixa no topo, como a da Frieren, repita a cor: `["#C2546A", "#C2546A", "#1F5F78", ...]` com `[0, 2.5, 9, ...]`.
- A última cor é a da faixa com o nome.
- Você não precisa saturar as cores: o script já aumenta a saturação em cerca de 20% para compensar a cola de glitter e o cabochão. Isso fica na função `viv`, na linha 29, onde `sat=1.22` é a intensidade.

**2. Meia-lua e sombra.** No dicionário `ST` (linha 46), cada personagem tem uma entrada:

```python
"NOME": dict(cres=("#cor_clara", .55, .34), top=("#cor_escura", .2, .2)),
```

- `cres` é a meia-lua clara embaixo: (cor, intensidade, altura).
- `top` é a sombra suave no topo: (cor, intensidade, tamanho).
- Pode deixar só um dos dois, ou `dict()` para nenhum.

**3. Efeitos esfumados (opcional).** Também no `ST`:

- `glow=[("#cor", intensidade, tamanho, deslocamento_vertical)]`: brilho no centro. Intensidade entre .25 e .6; tamanho .5–.7.
- `mist=("#cor", intensidade, angulo_inicial, angulo_final)`: névoa na borda, como no Viego (30–150 = topo) e na Lillia (200–340 = base).
- `rim=("#cor", intensidade, largura)`: borda escura esfumada, como no Tanjiro, na Caitlyn e na Vi.

Importante: só aparecem os efeitos dos nomes listados em `KEEP_FX` (linha 371). Adicione o nome lá para ativar.

**4. Temas.** Na lista `THEMES` (linha 468), cada tema tem o título que aparece na folha, o nome do PDF e os personagens. O script já ordena em ordem alfabética e coloca 6 por folha. A regra especial da Apotecária (Jinshi e Maomao com o dobro de olhos) fica logo abaixo, perto da linha 491.

## Antes de imprimir

- Imprima em **tamanho real (100%)**, nunca em "ajustar à página".
- Confira a régua do rodapé: ela precisa medir exatamente 5 cm.
- Em papel fotográfico, use a opção "papel fotográfico brilhante" e qualidade alta, e espere secar bem antes de cortar.

## Dica para criar novos

Mande prints de close dos olhos para o Claude junto com o prompt padrão. Ele devolve as cores e as linhas já no formato acima, e é só colar no script.
